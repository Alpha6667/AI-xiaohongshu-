from dataclasses import dataclass
import json
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from fastapi import HTTPException, status

from app.models.enums import PostStatus, PublishStatus
from app.models.post import Post
from app.models.publish_log import PublishLog
from app.db.config import get_settings
from app.repositories.memory import new_id, now_iso, repository


@dataclass(slots=True)
class PreparedPublish:
    post: Post
    publish_log: PublishLog


class MetricsFetchError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


class FakePublisherAdapter:
    def prepare_publish(self, post: Post, operator: str) -> PreparedPublish:
        if post.status != PostStatus.APPROVED:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Only approved posts can enter publishing")

        if any(
            repository.publish_logs[log_id].status in {PublishStatus.QUEUED, PublishStatus.SUCCEEDED}
            for log_id in post.publish_log_ids
            if log_id in repository.publish_logs
        ):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Publish already queued or completed")

        created_at = now_iso()
        publish_log = PublishLog(
            id=new_id("publish"),
            post_id=post.id,
            status=PublishStatus.QUEUED,
            detail=f"Publish requested by {operator}",
            created_at=created_at,
        )
        repository.publish_logs[publish_log.id] = publish_log
        post.publish_log_ids.append(publish_log.id)
        post.status = PostStatus.PUBLISHING
        post.updated_at = created_at
        return PreparedPublish(post=post, publish_log=publish_log)

    def submit_publish(self, prepared: PreparedPublish, operator: str) -> PreparedPublish:
        prepared.publish_log.detail = f"Submitted to OpenClaw by {operator}"
        prepared.post.updated_at = now_iso()
        return prepared

    def fetch_metrics(self, post: Post) -> dict[str, int]:
        settings = get_settings()
        metrics_url = getattr(settings, "openclaw_metrics_webhook_url", "")
        if not metrics_url:
            raise MetricsFetchError("metrics_fetch_not_configured", "OpenClaw metrics webhook URL is not configured")
        if not post.platform_post_id:
            raise MetricsFetchError("platform_post_id_missing", "Platform post id is required for metrics fetch")

        payload = json.dumps({"postId": post.id, "platformPostId": post.platform_post_id}).encode("utf-8")
        request = Request(metrics_url, data=payload, method="POST")
        request.add_header("Content-Type", "application/json")

        auth_token = getattr(settings, "openclaw_metrics_auth_token", "")
        if auth_token:
            request.add_header("Authorization", f"Bearer {auth_token}")

        timeout_seconds = max(1, int(getattr(settings, "openclaw_metrics_timeout_seconds", 10)))

        try:
            with urlopen(request, timeout=timeout_seconds) as response:
                content = response.read().decode("utf-8")
        except HTTPError as exc:
            raise MetricsFetchError("metrics_fetch_http_error", f"Metrics fetch http error: {exc.code}") from exc
        except URLError as exc:
            raise MetricsFetchError("metrics_fetch_network_error", f"Metrics fetch network error: {exc.reason}") from exc

        try:
            raw = json.loads(content)
        except json.JSONDecodeError as exc:
            raise MetricsFetchError("metrics_fetch_invalid_response", "Metrics fetch response is not valid JSON") from exc

        required_keys = ("views", "likes", "favorites", "comments", "followConversions")
        missing_keys = [key for key in required_keys if key not in raw]
        if missing_keys:
            raise MetricsFetchError("metrics_fetch_invalid_payload", "Metrics response missing required fields")

        try:
            return {
                "views": int(raw["views"]),
                "likes": int(raw["likes"]),
                "favorites": int(raw["favorites"]),
                "comments": int(raw["comments"]),
                "followConversions": int(raw["followConversions"]),
            }
        except (TypeError, ValueError) as exc:
            raise MetricsFetchError("metrics_fetch_invalid_payload", "Metrics response contains invalid numeric fields") from exc


publisher_adapter = FakePublisherAdapter()
