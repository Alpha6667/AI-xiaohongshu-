# Frontend Sync

## 第十三轮生图模型配置页任务

- 当前新增一轮前端任务：补可视化“模型设置页”，承接生图厂商选择、Key 录入、默认模型自动切换和无 Key 空态。
- 直接阅读：
  - `.monkeycode/docs/IMAGE_MODEL_PROVIDER_INTEGRATION_PLAN.md`
  - `.monkeycode/docs/IMAGE_MODEL_PROVIDER_FRONTEND_TASK.md`
- 当前用户还没有真实 Key，因此本轮不以真实出图联调为阻塞条件。
- 本轮重点是先把页面结构、交互、脱敏展示和与 `/review` 的错误提示链路搭好。

## 当前优先级说明

- 下一阶段执行顺序以 `.monkeycode/docs/NEXT_PHASE_EXECUTION_PLAN.md` 为准。
- 前端当前最优先的两个动作是：先去掉真实帖子详情页里的种子账号主路径兜底，再承接真实生成结果和准备状态展示。

## 第八轮消息入口与多账号升级同步

- 第七轮已完成“发帖工作台”产品化重做，但整体仍是单账号日常发帖视角。
- 第八轮需要把前端继续升级到新的产品框架：`OpenClaw 对话入口 + 后台确认 + 多账号运营`。
- 本轮目标不是扩真实平台能力，而是先把页面结构、信息组织和操作路径改对。

### 本轮目标

1. 把产品起点从“进入后台发帖”切换为“先通过 OpenClaw 发消息下达任务”。
- 页面上必须明确体现消息来源、任务转化、确认入口、账号归属和结果查看。

2. 把后台从“单账号操作台”升级为“消息入口后的确认与管理后台”。
- 后台重点不再是从零输入主题，而是接住消息任务、确认内容、指定账号、查看结果与数据。

3. 把“多账号运营”提升为主视角之一。
- 多账号不能继续隐藏在概念文案里，必须有独立页面和明确入口。

### 本轮页面与路由要求

1. `/` 总览首页升级
- 第一屏优先回答：今天有哪些消息任务、哪些任务待确认、哪些账号今天有发布任务、最近结果怎么样。
- 现有“单账号已接入”“今天待发”这类表达需要改成多账号和消息任务视角。
- 首页应能直接跳转到消息任务中心、内容确认台、发布中心。

2. 新增 `/tasks` 消息任务中心
- 这是本轮必须新增的页面。
- 页面要明确展示：用户发给 OpenClaw 的消息、系统整理出的任务、当前任务所处阶段、是否已生成文案、是否已生成图片、是否等待人工确认。
- 这一页是“聊天入口”和“后台操作”之间的桥，不能做成普通列表页。

3. 新增 `/accounts` 多账号运营页
- 这是本轮必须新增的页面。
- 页面至少展示：账号名称、在线状态、今日任务、最近表现、当前待处理项。
- 页面目标是让用户一眼看懂“多个账号现在分别在做什么”，不是简单账号设置页。

4. `/review` 从“发帖工作台”升级为“内容确认台”
- 保留候选文案、候选图片、最终预览这些核心区域。
- 新增或强化“当前消息任务来源”“当前发布账号”“确认后交给 OpenClaw 执行”的表达。
- 默认文案不能继续让用户感觉是在从零创建内容，而应是确认系统已经生成好的候选结果。

5. `/dashboard` 发布中心继续保留
- 强化 OpenClaw 执行叙事：是否已接收最终内容、是否已上传、是否已提交审核、是否审核通过、失败后下一步做什么。
- 页面要能和消息任务、账号归属形成对应关系，而不是孤立展示状态。

6. `/posts` 与 `/posts/[id]` 强化多账号视角
- 列表和详情都要能看出“哪个账号发了哪条内容”。
- 除帖子本身外，要突出账号归属、发布时间、互动数据和后续复盘建议。

### 数据与实现边界

1. 本轮先做前端产品结构，不阻塞于后端是否已提供“消息任务”和“多账号”的真实接口。
- 若当前后端尚未提供对应接口，可在前端展示层增加适配数据或演示数据，但要和现有 `posts`、`dashboard` 数据保持叙事一致。
- 不要自行扩展真实小红书平台行为，不要伪造复杂平台字段。

2. 现有数据优先复用
- 继续优先复用当前 `posts`、`assets`、`dashboard` 等接口。
- 如需补展示层数据组织，优先放在 `frontend/src/lib/product.ts` 或相邻的展示层工具中统一处理。

3. 导航和整体文案必须同步升级
- `frontend/src/components/app-shell.tsx` 中当前“单账号日常发帖闭环”等文案需要改掉。
- 导航中应新增“消息任务中心”和“多账号运营”入口。

### 本轮必须交付

1. 新页面
- `frontend/src/app/tasks/page.tsx`
- `frontend/src/app/accounts/page.tsx`

2. 现有页面升级
- `frontend/src/app/page.tsx`
- `frontend/src/app/review/page.tsx`
- `frontend/src/app/dashboard/page.tsx`
- `frontend/src/app/posts/page.tsx`
- `frontend/src/app/posts/[id]/page.tsx`
- `frontend/src/components/app-shell.tsx`

3. 展示层适配
- 视需要新增或扩展展示层工具，统一承接消息任务、多账号、账号归属、阶段文案和建议文案。

4. 验证
- 执行 `cd frontend && npm run lint`
- 执行 `cd frontend && npm run build`

### 本轮不要先做

- 不要等待真实消息接口或真实多账号后端能力就绪后再开始页面重构。
- 不要把多账号能力继续塞回设置页、角落入口或仅用一两句文案带过。
- 不要继续沿用“单账号已接入”“单账号日常发帖闭环”这类旧叙事。
- 不要把页面做成纯状态卡堆叠，必须明确任务来源、账号归属、操作去向。

### 原型参考

- `product-prototype/index.html`
- `product-prototype/message-center.html`
- `product-prototype/accounts.html`
- `product-prototype/composer.html`
- `product-prototype/publish-center.html`
- `product-prototype/posts.html`

### 完成后回复格式

- commit hash
- commit message
- 改动文件列表
- 页面改动说明
- 数据适配策略说明
- `npm run lint` 结果
- `npm run build` 结果
- `git status --short`

## 已完成

- 已将前端主链路从“单账号发帖工作台”重排为“消息 -> 任务 -> 确认 -> 发布 -> 数据”。
- 首页 `/` 已改为任务总览，优先展示今天的消息任务、待确认任务和有任务的账号。
- 已新增 `/tasks` 消息任务中心，展示聊天入口如何转成后台任务、内容准备度和确认入口。
- 已保留旧 `/messages` 入口跳转到 `/tasks`，避免现有预览路径失效。
- 已新增 `/accounts` 多账号运营页，展示账号在线状态、今日任务、待处理量和最近互动结果。
- `/review` 已改为内容确认台，支持确认候选文案、候选图片，并选择由哪个账号发布。
- `/dashboard` 已改为多账号视角的发布中心，强调 OpenClaw 执行状态、平台回写、失败分类和下一步建议。
- `/posts` 与 `/posts/[id]` 已补多账号上下文，能看到账号归属、原始消息任务和数据表现。
- `frontend/src/lib/product.ts` 已新增前端视图模型，用现有 `posts`、`dashboard`、`assets` 接口构造消息任务和账号运营视图。
- 已执行 `cd frontend && npm run lint`，通过。
- 已执行 `cd frontend && npm run build`，通过。

## 当前问题

- 2026-04-30 已开始本轮页面收口，不扩新页面，只提升已有页面的完成度。
- `/posts/[id]` 已新增“刷新指标数据”按钮，前端接入 `POST /api/posts/{post_id}/refresh-metrics`，成功后通过 `router.refresh()` 重新拉取详情页 SSR 数据，因此 `latestMetrics` 与 `metricsHistory` 会一起更新。
- `refresh-metrics` 失败时，前端会优先承接后端 `detail` 字段；若命中 `metrics_fetch_failed:<error_code>`，当前已对登录失效、页面结构变化、超时、帖子未找到、网络异常、暂不可用、浏览器抓取异常等错误码给出中文提示。
- `/posts` 与 `/posts/[id]` 正在去掉“联调面板感”：列表与详情会优先按发布时间、当前状态、平台回写和数据表现组织阅读顺序，减少直接暴露技术字段。
- 本轮同时补齐页面级标题与描述：`/posts`、`/posts/[id]`、`/settings/models`。

- 2026-04-29 已新增 `/settings/models`，用于配置生图厂商、API Key、默认模型和可选 Base URL；全局导航已补“AI 生成设置”入口。
- 前端已新增 `GET /api/settings/image-provider`、`POST /api/settings/image-provider`、`POST /api/settings/image-provider/test` 的客户端封装与类型定义，并按后端最终契约联调。
- `GET /api/settings/image-provider` 现在只按 `provider`、`imageModel`、`baseUrl`、`hasKey`、`maskedKey`、`updatedAt` 渲染页面状态，不依赖任何明文 key。
- `POST /api/settings/image-provider` 保存时允许只传 `provider`；若前端未手动改模型名，则不传 `imageModel`，直接承接后端默认模型补齐逻辑。
- `POST /api/settings/image-provider/test` 现在按业务响应体解析，不只看 HTTP 状态：前端会读取 `ok` 与 `code`，对 `provider_not_configured` 和 `provider_model_not_configured` 给出明确提示。
- `/review` 的“刷新候选内容”现在只按真实 `generate-images` 错误语义识别设置缺口：命中 `provider_not_configured` 或 `provider_model_not_configured` 时，会明确提示去 `/settings/models` 完成配置，不再沿用旧的宽泛兜底判断。
- 厂商切换已按文档内置默认模型映射：`openai -> gpt-image-1`、`bfl -> flux.2`、`volcengine -> seedream`、`tencent -> hunyuan-image`、`alibaba -> wanx`、`stability -> stable-image`；切换厂商后页面会自动带出推荐模型，但仍允许手动改名。
- 设置页读取配置时只展示 `maskedKey` / `hasKey`，不提供完整 Key 回显或复制完整 Key 的入口，页面文案也已明确 Key 只用于服务端请求第三方模型。

- 2026-04-24 已开始第三优先级真实展示收口：`/accounts` 已切到账号连接状态、最近验证、最近同步和错误摘要主路径展示；`/review`、`/dashboard`、`/posts`、`/posts/[id]` 已开始统一消费 `connectionStatus`、`lastSyncAt`、`lastSyncStatus`、`reviewStatus`、`under_review`、`rejected`、互动计数字段。
- `frontend/src/lib/product.ts` 现已统一补齐“同一份确认对象”说明、账号可真实发布提示、平台审核中/审核未通过语义、作品同步状态和互动数据优先级（优先用 `likeCount` / `collectCount` / `commentCount`，缺失时再回落 `latestMetrics`）。
- 内容确认台现在会在保存确认版时真实回写 `post.accountId`，因此所选发布账号不再只是纯前端临时选择。
- `/posts` 已改为展示真实帖子主表，不再只看 `published`；列表里会同时露出平台审核中、审核未通过和同步结果。
- 当前仍需后端继续稳定返回 `platformUrl`、账号连接字段和同步字段，前端现在已经有展示位，但部分真实样本可能仍为空。

- 后端已补齐 `GET /api/tasks` 与 `GET /api/accounts` 的主要展示字段，前端这轮开始把 `title`、`stageLabel`、`nextAction`、`accountName`、`plannedAt`、`requiresHumanReview` 以及账号聚合字段作为主路径消费。
- 当前已进一步收口账号归属展示：如果接口成功但帖子或任务没有真实 `accountId` / `accountName`，页面会明确显示“未分配账号”，不再回退到种子账号。
- 后端真实 `stage` 使用 `pending_generation`、`waiting_review` 等枚举，前端仍需要一层轻量归一化，映射到现有页面内部的展示阶段。
- `/review` 已去掉本地伪造候选：只有后端真实返回标题、正文、标签、素材时才展示，否则明确显示“文案/图片还没生成完成”的空态。
- `/posts/[id]` 已补“尚未生成完成 / 文案已生成 / 图片已生成 / 已可确认”真实准备度展示，不再只靠帖子状态做模糊判断。
- 2026-04-24 已完成 `/review`、`/dashboard`、`/posts/[id]` 的真实发布状态统一：页面现在统一使用“待交给 OpenClaw / 已交给 OpenClaw / 执行中 / 已发布 / 发布失败”这组中文语义，不再直接暴露 `queued`、`succeeded`、`failed` 原始英文结果。
- `/review` 的“交给 OpenClaw 去发”动作现在会直接承接真实 `publish` 接口返回，并把状态说明、失败分类和回写详情同步展示到确认台提示中。
- `/dashboard` 现已优先消费真实发布记录展示 OpenClaw 回写、当前发布进度和下一步动作建议；接口成功时不再保留演示态状态文案。
- `/posts/[id]` 现已补齐最近一次发布结果的中文状态、记录时间、平台回写标识、失败原因和失败分类，并与 `/review`、`/dashboard` 使用同一套发布状态映射。
- 2026-04-24 已完成 `/tasks` 页面源码级真实验收：页面 HTML 中已命中 `QQ 发唯一测试消息`、`QQ 去重复验 20260424` 和 `待生成`，且未命中“当前仍在使用展示层回退任务数据”，说明当前页面已展示真实任务而非 fallback 数据。
- 同次验收中，`QQ 去重复验 20260424` 在页面源码中仅出现 1 次，前端层面的去重展示也已通过。
- 2026-04-24 已完成 `/review` 页面动作验收：两条真实 QQ 任务均成功承接到 `/review?postId=...`，并验证了“保存确认版 -> 提交人工确认 -> 审核通过 / 审核退回”两条动作路径。
- 任务 A 最终状态已正确流转到 `approved`，任务 B 最终状态已正确回到 `draft`，且两条任务的 `reviewRecords` 都正确追加了两条操作记录。
- 2026-04-24 已完成 `/dashboard` 页面源码级验收：页面 HTML 已命中 `发布中心`、`OpenClaw` 以及状态关键词 `待发送`、`发送中`、`已发布`、`发送失败`。
- 当前页面未命中失败分类关键词 `平台限流`、`可重试失败`、`不可重试失败`，原因是当前验收数据中没有失败发布样本，属正常结果。
- 2026-04-24 已完成 `/posts` 页面源码级验收：页面当前已直连真实 `GET /api/posts` 和 `GET /api/dashboard/summary`，线上展示的唯一列表项 `post_seed_published` 与接口返回的已发布真实记录一致，不是列表 fallback 数据。
- 2026-04-24 已完成 `/posts/[id]` 详情页验收：`/posts/post_seed_published` 与 `/api/posts/post_seed_published` 的已发布状态、平台 ID、素材、指标历史一致；`/posts/post_f01d2157a6` 也已正确展示真实 `approved` 状态和两条 `reviewRecords`。
- 当前仍有一个明确缺口：当真实 `post.accountId` 与 `task.accountId` 都为空时，详情页“归属账号”仍会回退到前端种子账号；例如 `post_f01d2157a6` 当前展示为 `小鹿的穿搭日记`，这不是后端真实归属。
- 当前 `/posts` 列表只展示 `status === "published"` 的帖子，因此本轮 QQ 验收产生的 `approved` / `draft` 真实帖子不会自然出现在列表中，需等待真实发布样本或调整页面策略后再继续验收列表承接。

## 需要协作

- 仍建议后端继续保持 `GET /api/tasks` 和 `GET /api/accounts` 的字段稳定，避免前端再次回到聚合推导路径。
- 仍需要后端在 `GET /api/posts` 与 `GET /api/posts/{id}` 中持续稳定返回 `accountId`、`messageTaskId`，这样帖子列表、详情页和内容确认台才能完全去掉归属兜底。

## 下一步

- 等后端补齐 `image-provider` 配置接口后，前端可直接把 `/settings/models` 从草稿模式切到真实保存、真实读取和真实测试。
- 如果后端把 `generate-images` 的失败语义稳定收口到 `provider_not_configured` 或明确中文 detail，前端现有确认台提示可以直接承接，不需要再重做页面结构。
- 当前前端已经把真实页面里的账号展示和发布状态都切到后端真实结果主路径；下一步如果联调稳定，可继续删除仅用于整页演示回退的种子账号逻辑。
- 在接口稳定前，前端暂只保留“接口请求失败时整页回退”的最小兼容，不再把种子账号或演示发布状态用于接口成功但字段为空的页面。
- 如果后端后续补充更细的生成链路字段（如独立 copy/image task 状态），前端可以继续把 `/tasks` 和 `/posts/[id]` 的准备度从布尔值升级为更细粒度进度展示。

## 第七轮页面重做同步

- 本轮已将前端主体验从“联调/演示后台”重做为“更接近日常真实使用的小红书发帖工作台”。
- 页面结构按真实操作顺序重排，不再按接口模块拆页。

### 本轮已完成

1. 四个核心页面重定位
- `/` 重做为总览首页，先看账号状态、今天待发主题、AI 候选准备度和最近发送结果。
- `/review` 重做为发帖工作台，把 AI 候选文案、候选图片、手机预览和推进动作放到同一条工作流里。
- `/dashboard` 重做为发布中心，聚焦 OpenClaw 发送进度、平台审核结果和下一步动作。
- `/posts` 重做为帖子与数据页，聚焦已发布内容与浏览、点赞、收藏、评论等复盘信息。

2. 详情页同步产品化
- `/posts/[id]` 已同步改成中文产品化详情，不再展示接口边界卡片。
- 详情页现在直接展示最终稿、发送回写、素材、指标历史、人工确认记录和下一步建议。

3. 展示层辅助逻辑收口
- 新增 `frontend/src/lib/product.ts`，统一处理状态中文语义、失败分类、发送叙事、候选文案构造和表现建议。

4. 验证结果
- 已执行 `cd frontend && npm run lint`，通过。
- 已执行 `cd frontend && npm run build`，通过。

### 本轮仍然遵守的边界

- 本轮没有扩新业务边界。
- 没有新增多账号、复杂定时发布或真实平台能力假设。
- 仍主要复用现有 `posts`、`assets`、`dashboard`、`publish`、`review` 等接口做产品化重组。

## 第一阶段职责

- 完成 `frontend/` 后台页面基础骨架
- 负责后台 UI 设计与视觉风格落地
- 完成看板、帖子列表、内容工作台、审核页的基础页面结构
- 与后端对齐接口字段并预留真实数据接入位

## 当前分配任务

### 第六轮主任务

- 第六轮以前端体验收口和预览访问方式收口为主，不再回到基础接线阶段。
- 当前重点是把后台从“可跑通”推进到“更适合持续演示和继续开发”的状态。

### 本轮必须交付

1. 工作台选择逻辑收口
- 不再默认选择第一篇可编辑草稿作为当前工作对象
- 明确当前工作草稿的选择、切换和空状态展示

2. 发布结果信息收口
- 收口 `publishing`、`published`、`publish_failed` 的展示层级
- 稳定展示 `platformPostId`、失败原因、发布时间等结果信息

3. 指标历史状态收口
- 为详情页指标历史补空状态、无数据状态或异常状态
- 不只覆盖“有数据”的正常渲染场景

4. 预览访问方式收口
- 为远程预览环境下的客户端请求补稳定访问方案
- 优先采用 `/api` 同源代理或等效转发方式，减少环境差异对按钮点击回归的影响

### 本轮不要先做

- 不要先扩新业务页面
- 不要先重做整体视觉系统
- 不要先自行假设真实小红书平台字段或行为

### 当前最高优先级

- 当前先不启动第六轮新功能，优先补前端依赖环境并恢复基础工程验证能力。
- 目标是让 `frontend/package.json` 中现有脚本至少能成功执行 `npm run lint` 或 `npm run build` 之一，消除 `next: not found` 阻塞。

### 当前必须先做

1. 依赖环境补齐
- 在 `frontend/` 下安装 `package.json` 已声明依赖，优先使用当前仓库已有脚本约定的 `npm` 流程
- 安装完成后确认 `next` 可执行，不再出现 `next: not found`

2. 基础工程验证
- 先执行 `npm run lint`
- 若 `lint` 仍因环境或脚本问题失败，再执行 `npm run build` 补充验证
- 将执行结果、失败原因或剩余环境限制写入本文件同步区

3. 回归范围
- 依赖恢复后，至少回归发布状态展示、发布结果信息展示、指标历史展示这三条第五轮主链路
- 不要在本轮顺手扩新页面或改业务边界

### 第五轮当前执行任务

- 后端第五轮持久化、发布结果回写、指标快照追加写入已经落库，前端不再等待后端主链路完成。
- 当前优先级切到展示收口与真实回归，重点验证发布状态流转、发布结果信息和指标历史展示。

### 本轮必须优先完成

1. 发布状态收口
- 在列表页、详情页或工作台中至少一处明确展示 `publishing`、`published`、`publish_failed`
- 若页面当前只显示帖子状态，需要核对并正确消费 `publishStatus` 的阶段信息

2. 发布结果信息收口
- 在详情页优先展示 `publishRecords` 中的 `platformPostId`
- 发布失败时明确展示 `errorMessage`，避免只有通用失败提示

3. 指标历史真实渲染
- 用后端当前返回的 `metricsHistory` 验证快照追加后是否能形成真实历史序列
- 若仍有字段不足以支撑图表，必须在同步区写清具体缺口，不自行假设字段

4. 环境验证
- 依赖可用后优先执行 `next lint` 或 `next build`
- 若仍卡在依赖或命令不可用，需把阻塞信息写入同步区

### 第五轮待命任务

- 第五轮以前端验证和展示收口为主，等待后端完成持久化与发布/指标链路补全
- 后端能力就绪后，优先补发布状态展示、失败提示和指标历史真实渲染

### 本轮必须交付

1. 发布状态展示
- 展示 `publishing`
- 展示 `published`
- 展示 `publish_failed`
- 若后端返回 `publishStatus`、`message`、错误信息，页面要能正确反馈

2. 发布结果信息展示
- 若详情页返回 `platform_post_id`，页面可展示平台帖子标识
- 若发布失败返回错误说明，页面可展示失败原因

3. 指标历史展示跟进
- 若后端已返回真实指标历史或快照，替换现有占位展示
- 在同步区明确哪些指标仍是占位，哪些已切到真实数据

4. 环境验证
- 依赖可用时优先执行 `next lint` 或 `next build`
- 若仍受环境限制，必须在同步区说明

### 本轮不要先做

- 不要先扩新页面
- 不要先改动后端未完成的真实平台行为假设
- 不要先为了视觉重构已稳定页面

### 第四轮待命任务

- 第四轮以前端接线与验证为主，等待后端补齐素材查询和生成/发布契约
- 后端接口一旦可用，立即替换素材卡片 mock，并接通生成与发布入口

### 本轮必须交付

1. 素材卡片改真实数据
- 在后端素材查询能力可用后，移除本地素材卡片 mock
- 验证上传后带 `postId` 时，详情页能正确反映关联素材

2. 接通生成与发布入口
- `generate-copy`
- `generate-images`
- `publish`
- 为按钮状态、加载态、错误反馈补齐最小交互

3. 完成联调验证
- 验证看板字段映射与后端聚合字段一致
- 在同步区写明剩余未接线动作和依赖限制

### 本轮不要先做

- 不要先重做工作台布局
- 不要先扩展新的业务页面
- 不要在后端契约未稳定前自行假设字段

### 第三轮任务

- 第三轮以真实接口联调为主，不再以静态展示为主
- 重点把页面主数据、审核动作、素材关联动作切到真实后端
- 本轮只允许保留必要的局部 mock，占位范围需要在同步区说明

### 本轮必须交付

1. 接通真实列表与详情
- `GET /api/posts`
- `GET /api/posts/{post_id}`
- 详情页按固定字段渲染：`reviewRecords`、`publishRecords`、`metricsHistory`

2. 接通真实看板
- `GET /api/dashboard/summary`
- 用真实聚合值替换原有 mock 主数据

3. 接通真实审核与保存链路
- `submit-review`
- `approve`
- `reject`
- 工作台保存后刷新当前页面状态

4. 接通素材上传后的页面反馈
- 若上传时传 `postId`，页面要能反映素材已关联到帖子

### 本轮不要先做

- 不要先扩展趋势图
- 不要先大改 UI 结构
- 不要先做数据库相关适配假设

### 今天的第二轮任务

- 开始从 mock 页面切到真实接口联调
- 重点完成 `dashboard`、`posts`、`posts/[id]`、`review` 的真实数据接入
- 本轮不重做视觉设计，优先保证现有 UI 在真实数据下稳定运行

### 本轮必须交付

1. 接入真实看板接口
- 使用 `GET /api/dashboard/summary`
- 本轮只消费聚合数值，不等待趋势字段

2. 接入真实帖子列表和详情接口
- 使用 `GET /api/posts` 和 `GET /api/posts/{post_id}`
- 详情页直接使用 `reviewRecords`、`publishRecords`、`metricsHistory` 字段名

3. 接通审核动作
- 接入 `submit-review`、`approve`、`reject`
- 在 UI 上补齐操作反馈、按钮状态和错误提示占位

4. 收敛 mock 使用范围
- 页面主数据改为真实接口
- 只保留前端确实无法从后端获取的局部展示占位

### 本轮不要先做

- 不要先扩展趋势图维度
- 不要先重构页面结构
- 不要先做多账号或权限系统

### 本轮目标

- 先把后台前端做成可演示的静态工作台
- 先解决信息架构、布局、视觉气质和页面主链路可见性
- 在后端接口未完成前，全部用 mock 数据和占位交互支撑演示

### 本轮必须交付

1. 完成 `dashboard` 页面
- 展示核心指标总览、近期内容表现区、待处理事项区
- 不要只做一排普通统计卡，要有明显的信息层级

2. 完成 `posts` 和 `posts/[id]` 页面
- 列表页展示状态、发布时间、封面、标题、最新指标
- 详情页展示内容、审核记录、发布记录、指标趋势占位

3. 完成内容工作台入口
- 支持主题输入、标题/正文编辑、标签区、图片上传区、AI 生成按钮
- 页面要让“生成 -> 编辑 -> 提交审核”链路一眼可懂

4. 完成 `review` 页面
- 展示待审核内容
- 展示审核意见输入区和批准/退回操作区

5. 完成统一后台框架
- 统一布局、导航、页面容器、卡片、状态标签、按钮层级
- 保证整体风格统一，不要每个页面像不同系统拼起来的

### 提交前自检

- 新路由已落到 `frontend/src/app`
- 页面使用的字段命名与 `API_CONTRACT.md` 对齐
- mock 数据集中管理，后续可替换为真实接口
- UI 风格符合“高级感、内容工作台、非模板后台”要求
- 开发完成后更新本文件底部同步区

## 视觉目标

- 整体气质需要有高级感，不做通用模板式后台
- 视觉关键词：克制、精致、留白、内容感、编辑感、品牌工作台感
- 优先使用浅色背景配合高对比文字、柔和边框、适度圆角和少量强调色
- 避免廉价渐变、大面积高饱和色块、过重阴影和杂乱卡片堆叠

## 第一阶段必须先做的任务

### 1. 路由与布局骨架

- 在 `frontend/src/app` 下补齐：
  - `dashboard/`
  - `posts/`
  - `assets/`
  - `review/`
- 增加统一后台布局，包括：
  - 顶部标题区
  - 左侧导航或轻量侧边栏
  - 内容区容器
- 抽出通用页面容器和卡片组件，避免每页各写各的

### 2. 第一批页面

- `dashboard`
  - 展示总帖子数、浏览、点赞、收藏、评论、关注转化
  - 先用 mock 数据占位
- `posts`
  - 展示帖子列表、状态标签、发布时间、最新指标
- `posts/[id]`
  - 展示帖子详情、草稿内容、审核记录、发布记录、指标历史占位
- `review`
  - 展示待审核内容、审核意见输入区、批准/退回操作区
- 内容工作台入口
  - 提供主题输入、标题正文编辑、标签区域、图片上传区域、AI 生成按钮

### 3. 交互与数据边界

- 先封装统一 API Client 与 mock 数据层
- 所有页面先按 `API_CONTRACT.md` 的接口命名和字段边界预留
- 在后端接口未完成前，前端先用本地 mock 保持页面可演示

### 4. 当前不需要你先做的内容

- 多账号页面
- 登录权限系统
- 定时发布页面
- 复杂主题切换系统

## UI 设计要求

### 页面气质

- 更像内容运营工作台，而不是传统 ERP 后台
- 要体现“AI 内容创作平台”的精致感和专业感

### 具体要求

- 看板页要有清晰的层级，不要只是一排普通统计卡
- 列表页要重视状态标签、数字对齐、留白和信息密度控制
- 编辑页要让“主题输入 -> AI 生成 -> 人工修改 -> 提交审核”这条链路一眼可懂
- 审核页要突出当前版本内容、修改区域和操作按钮的优先级

### 不希望出现的风格

- 通用管理后台模板感太强
- 组件堆砌但没有视觉主次
- 花哨但不专业
- 过度依赖大面积蓝色渐变或炫技动画

## 每次同步请按这个格式写

```markdown
## 已完成
- ...

## 当前问题
- ...

## 需要协作
- ...

## 下一步
- ...
```

## 本轮同步区

## 已完成
- 已将 `dashboard`、`posts`、`posts/[id]`、`review` 的主数据从本地 mock 切换到真实接口。
- 已按后端当前字段名消费 `reviewRecords`、`publishRecords`、`metricsHistory`，详情页直接渲染真实返回结构。
- 已接入 `GET /api/dashboard/summary`、`GET /api/posts`、`GET /api/posts/{post_id}` 并保留现有 UI 结构不做大改。
- 已完成工作台中的真实保存与 `submit-review` 动作接线，并在审核页接入 `approve`、`reject` 按钮行为。
- 已在工作台补上 `POST /api/assets/upload` 的真实上传入口，上传时携带 `postId`，成功后会提示素材已关联并刷新页面状态。
- 已按第四轮待命任务接通 `POST /api/posts/{post_id}/generate-copy`、`POST /api/posts/{post_id}/generate-images`、`POST /api/posts/{post_id}/publish`，补齐按钮加载态、错误反馈和刷新逻辑。
- 已移除工作台和详情页中的素材卡片 mock，直接使用 `GET /api/posts/{post_id}` 返回的 `assets` 渲染真实素材卡片。
- 已将 `assets` 页面切到真实 `GET /api/assets` 列表接口，避免素材相关页面继续依赖本地卡片结构。
- 已验证并接通素材上传关联回填展示：上传时传 `postId` 后，页面刷新后会同时显示更新后的 `assetIds` 和 `assets`。
- 已按第四轮后端契约展示生成与发布反馈：`generate-copy` 展示 `message`，`generate-images` 展示 `message`，`publish` 展示 `publishStatus` 和 `message`。
- 已核对看板字段映射仍对应后端聚合字段：`totalPosts`、`totalViews`、`totalLikes`、`totalFavorites`、`totalComments`、`followConversions`、`pendingReviewCount`、`publishedCount`。
- 已按第五轮待命任务补充真实发布状态展示：`publishing`、`published`、`publish_failed` 在工作台、列表页、详情页均有明确状态反馈。
- 已在详情页增加发布状态回写区，展示 `platformPostId`、发布时间和最近一次发布结果说明，便于核对后端回写是否生效。
- 已将详情页“指标历史占位”改为真实指标历史展示，直接渲染 `metricsHistory` 的浏览、点赞、收藏、评论、关注转化快照。
- 已继续收口第五轮后端新增字段：详情页发布记录现已展示 `platformPostId`、`errorMessage`，工作台发布反馈也会优先透出平台 ID 或失败原因。
- 已在本轮再次尝试执行 `npm run lint`，确认当前环境仍因缺少 `next` 依赖而无法完成 `lint` / `build` 验证。
- 已在 `frontend/` 安装项目依赖，解决 `next: not found` 阻塞；当前 `next`、`react`、`react-dom` 及类型依赖已可用于本地校验。
- 已补充 `eslint`、`eslint-config-next` 和 `.eslintrc.json`，使 `npm run lint` 能以非交互方式执行。
- 已将 `next.config.ts` 中与当前 Next 15 不兼容的 `allowedHosts` 修正为 `allowedDevOrigins`，解除 `build` 的配置类型报错。
- 已修复 `typedRoutes` 下导航 `Link` 的路由类型问题，以及 mock 数据层的无用变量 lint 错误。
- 当前环境验证结果：`npm run lint` 已通过，`npm run build` 已通过。
- 已按第六轮要求收口工作台选择逻辑：首页不再默认抓取第一篇草稿，改为显式选择当前工作对象，并补齐未选择、非法 `postId`、无候选帖子三类状态。
- 已按第六轮要求收口发布结果展示：工作台与详情页均稳定展示 `publishing`、`published`、`publish_failed`，并优先透出 `platformPostId`、发布时间、失败原因和最新发布记录说明。
- 已按第六轮要求补齐指标历史状态卡：详情页除正常态外，新增空状态、无数据状态、历史读取异常、汇总不一致、发布后全 0 快照等提示。
- 已在前端补 `/api` 同源代理方案：`next.config.ts` 新增 `/api/:path*` rewrite，客户端默认回落到同源请求，减少远程预览环境下的后端地址差异。
- 已再次执行工程验证：`npm run lint` 通过，`npm run build` 通过，顺手清理了 `globals.css` 中的 `autoprefixer` 兼容告警。
- 已基于第六轮后端最新代码完成一轮真实联调回归：通过真实后端接口与 worker 写回函数，验证了保存、提交审核、审核通过、审核退回、发布入队、自动回写成功、自动回写失败、自动指标追加等链路。
- 已补前端对 `failureType` 的最小消费：`PublishResponse` / `publishRecords` 类型已接入该字段，工作台和详情页可展示 `retryable`、`non_retryable`、`rate_limited` 三类失败分类，不丢字段、不报错。
- 已完成预览环境回归：通过 `/api` 同源代理访问预览页，确认工作台草稿选择、审核页队列展示、详情页发布记录区和指标历史区都能消费第六轮后端返回结果。
- 已验证指标历史相关状态中的可达路径：
  - `post_seed_published` 可稳定展示“指标历史已回写”正常态。
  - 新建发布成功但未追加快照的帖子可展示“已发布但暂无历史快照”。
  - 审核退回后的草稿可展示“当前暂无指标历史”。
  - 发布成功且追加全 0 快照的帖子可展示“已发布但当前快照仍为 0”。

## 当前问题
- 当前没有新的前端工程阻塞，`lint` / `build` 和预览页回归均已通过。
- 详情页中的“历史尾项与最新汇总不一致”以及“历史快照读取异常”两条状态，在当前后端第六轮公开接口下未能直接复现：后端返回的 `latestMetrics` 会与历史尾项保持一致，且 `metricsHistory` 结构经 schema 校验后不会返回缺字段快照。
- 后端最小 API 测试当前仍缺 `httpx` 依赖，命令执行时会在 `fastapi.testclient` 初始化阶段失败；这不影响本轮前端联调回归结果。
- 安装依赖后仍有安全与维护提示：`npm install` 输出了 1 个 critical vulnerability，且部分上游包存在 deprecated 提示；本轮未额外处理升级，避免扩大范围。

## 需要协作
- 需要后端继续保持 `GET /api/posts/{post_id}` 中 `reviewRecords`、`publishRecords`、`metricsHistory` 三个字段稳定，不要在联调阶段改名。
- 后端已提供 `POST /api/posts/{post_id}/publish-result` 和 `POST /api/posts/{post_id}/metrics-snapshots`，前端需按现有详情返回结构验证 `publishStatus`、`platformPostId`、`errorMessage` 和指标历史追加结果。
- 需要后端保持 `platformPostId`、`publishedAt` 和发布失败明细的回写结构稳定，避免前端状态展示反复调整。
- 第六轮仍需要后端继续推进 worker 自动回写外壳和发布失败分类语义；前端当前只消费既有结果字段，不自行假设新的平台行为。
- 若后端后续希望前端真实覆盖“历史尾项与最新汇总不一致”或“历史快照读取异常”提示，需要提供可控的调试样本或专门测试夹具；当前公开接口无法稳定构造这两类数据。

## 下一步
- 若后端补充 `httpx` 依赖，可补跑 `backend/tests/test_api_minimal.py`，把本轮联调从“真实接口回归 + worker 测试”补齐到“后端最小 API 自动化测试”层面。
- 若后端后续开放可控异常样本，再补一次针对指标历史异常态的定向页面回归。
- 如后端后续开放 `GET /api/assets?postId=...` 的更多筛选或分页能力，前端再补素材库页的真实查询与筛选交互。
