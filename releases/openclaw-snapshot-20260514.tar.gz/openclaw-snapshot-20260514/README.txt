==========================================
OpenClaw + AI-Xiaohongshu 完整快照
打包时间: $(date)
==========================================

目录结构：
  openclaw.json                         — OpenClaw 配置（含 API key 占位符）
  auth-profiles.json                    — 认证配置
  exec-approvals.json                   — 执行审批配置
  workspace/skills/                     — publisher 脚本（server.js, xhs_publish.js, xhs_metrics.js）
  backend-data/repository.json          — 后端数据库（帖子/账号/metrics 数据）
  qq-forward-service/                   — QQ 消息转发服务
  systemd/                              — systemd 服务配置模板
  deploy.sh                             — 一键部署脚本

部署步骤：
  1. 拉取项目代码：
     git clone git@github.com:Alpha6667/AI-xiaohongshu-.git /srv/AI-xiaohongshu-
     cd /srv/AI-xiaohongshu- && git checkout 260509-chore-add-final-archive

  2. 安装依赖（Node.js, Playwright, Python）

  3. 复制本包内容到对应位置

  4. 配置 openclaw.json 中的 API key

  5. 启动服务

详细部署指南见仓库：
  .monkeycode/docs/DEPLOY_OPENCLAW_SETUP.md
  .monkeycode/docs/XHS_LOGIN_STATE_RUNBOOK.md
