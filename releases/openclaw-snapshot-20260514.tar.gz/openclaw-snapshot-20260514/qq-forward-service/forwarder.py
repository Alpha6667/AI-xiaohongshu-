#!/usr/bin/env python3
"""
QQ消息转发服务
监听OpenClaw的QQ消息并转发到AI-xiaohongshu后端
"""

import json
import hashlib
import httpx
import logging
from datetime import datetime, timezone

# 配置
BACKEND_URL = "http://127.0.0.1:8000/api/integrations/qq/messages"
SIGNATURE = "xhs-qq-ingest-2026-prod-9f3kLm72pQ"
LOG_FILE = "/var/log/qq-forward.log"

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def generate_event_id(sender_id: str, conversation_id: str, content: str, timestamp: str) -> str:
    """生成稳定的唯一事件ID"""
    data = f"{sender_id}:{conversation_id}:{content}:{timestamp}"
    hash_val = hashlib.sha256(data.encode()).hexdigest()[:16]
    return f"qq_event_{hash_val}"


async def forward_message(
    sender_id: str,
    sender_name: str,
    conversation_id: str,
    content: str,
    sent_at: str = None
) -> dict:
    """转发消息到后端"""
    
    if sent_at is None:
        sent_at = datetime.now(timezone.utc).isoformat()
    
    event_id = generate_event_id(sender_id, conversation_id, content, sent_at)
    
    payload = {
        "source": "qq",
        "senderId": sender_id,
        "senderName": sender_name,
        "conversationId": conversation_id,
        "content": content,
        "sentAt": sent_at,
        "eventId": event_id,
        "signature": SIGNATURE
    }
    
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                BACKEND_URL,
                json=payload,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 201:
                result = response.json()
                logger.info(f"转发成功: {event_id} -> {result.get('messageTaskId')}")
                return {"success": True, "data": result}
            else:
                logger.error(f"转发失败: {response.status_code} - {response.text}")
                return {"success": False, "error": f"HTTP {response.status_code}"}
                
    except Exception as e:
        logger.error(f"转发异常: {e}")
        return {"success": False, "error": str(e)}


def forward_sync(
    sender_id: str,
    sender_name: str,
    conversation_id: str,
    content: str,
    sent_at: str = None
) -> dict:
    """同步转发消息"""
    import asyncio
    return asyncio.run(forward_message(sender_id, sender_name, conversation_id, content, sent_at))


if __name__ == "__main__":
    # 测试
    result = forward_sync(
        sender_id="qq_u_test",
        sender_name="测试用户",
        conversation_id="qq_c2c_test",
        content="这是一条测试消息"
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))
