#!/bin/bash
# QQ消息转发脚本
# 用法: ./forward.sh <sender_id> <sender_name> <conversation_id> <content>

SENDER_ID="$1"
SENDER_NAME="$2"
CONVERSATION_ID="$3"
CONTENT="$4"
SENT_AT="${5:-$(date -u +"%Y-%m-%dT%H:%M:%S+00:00")}"

if [ -z "$SENDER_ID" ] || [ -z "$CONTENT" ]; then
    echo "用法: $0 <sender_id> <sender_name> <conversation_id> <content>"
    exit 1
fi

# 生成event_id (简化版)
EVENT_ID="qq_event_$(echo -n "${SENDER_ID}:${CONVERSATION_ID}:${CONTENT}" | sha256sum | cut -c1-16)"

# 调用后端API
curl -s -X POST "http://127.0.0.1:8000/api/integrations/qq/messages" \
    -H "Content-Type: application/json" \
    -d "{
        \"source\": \"qq\",
        \"senderId\": \"${SENDER_ID}\",
        \"senderName\": \"${SENDER_NAME}\",
        \"conversationId\": \"${CONVERSATION_ID}\",
        \"content\": \"${CONTENT}\",
        \"sentAt\": \"${SENT_AT}\",
        \"eventId\": \"${EVENT_ID}\",
        \"signature\": \"xhs-qq-ingest-2026-prod-9f3kLm72pQ\"
    }"
