#!/usr/bin/env python3
"""小红书作品指标抓取脚本

独立于发布流程，复用登录态 profile。
通过 creator 笔记管理页 DOM 解析每条笔记的互动数据。
"""

import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

PROFILE_DIR = os.getenv("XHS_PROFILE_DIR", "/root/.openclaw/xhs-profile-persist")
SCREENSHOT_DIR = os.getenv("XHS_SCREENSHOT_DIR", "/tmp/xhs-screenshots")
TIMEOUT_MS = int(os.getenv("XHS_METRICS_TIMEOUT_MS", "60000"))


def log(msg: str) -> None:
    print(f"[{datetime.now().isoformat()}] {msg}", flush=True)


def ensure_dirs() -> None:
    Path(PROFILE_DIR).mkdir(parents=True, exist_ok=True)
    Path(SCREENSHOT_DIR).mkdir(parents=True, exist_ok=True)


def parse_interaction_count(text: str) -> int:
    """解析小红书互动数文本: 1.2万 → 12000, 1234 → 1234"""
    if not text:
        return 0
    text = text.strip().replace(",", "").replace(" ", "")
    if not text:
        return 0
    if text.endswith("万"):
        try:
            return int(float(text[:-1]) * 10000)
        except (ValueError, TypeError):
            return 0
    try:
        return int(float(text))
    except (ValueError, TypeError):
        return 0


def fetch_metrics(platform_post_id: str, headless: bool = True) -> dict:
    logs: list[str] = [f"Metrics fetch for {platform_post_id}"]

    try:
        from playwright.sync_api import sync_playwright
        logs.append("Playwright imported")
    except ImportError as e:
        return {
            "success": False,
            "errorCode": "metrics_fetch_not_available",
            "errorMessage": f"Playwright not available: {e}",
            "executionLogs": logs,
        }

    ensure_dirs()

    try:
        with sync_playwright() as p:
            logs.append("Playwright started")

            context = p.chromium.launch_persistent_context(
                user_data_dir=PROFILE_DIR,
                headless=headless,
                args=[
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-gpu",
                ],
                viewport={"width": 1280, "height": 900},
            )
            logs.append("Browser context created")

            page = context.new_page()
            logs.append("Page created")

            try:
                # Step 1: Warm up session via home page
                logs.append("Warming up session")
                page.goto(
                    "https://creator.xiaohongshu.com/new/home",
                    timeout=TIMEOUT_MS,
                    wait_until="load",
                )
                time.sleep(3)

                if "login" in page.url.lower() and "/new/home" not in page.url:
                    logs.append("Login required")
                    context.close()
                    return {
                        "success": False,
                        "errorCode": "metrics_fetch_login_required",
                        "errorMessage": "小红书登录态失效，需要重新登录",
                        "executionLogs": logs,
                    }

                logs.append("Session OK")

                # Step 2: Navigate to note manager
                logs.append("Navigating to note manager")
                page.goto(
                    "https://creator.xiaohongshu.com/new/note-manager",
                    timeout=TIMEOUT_MS,
                    wait_until="load",
                )
                time.sleep(8)

                logs.append(f"Note manager URL: {page.url}")

                screenshot_path = os.path.join(
                    SCREENSHOT_DIR, f"metrics_{platform_post_id}.png"
                )
                page.screenshot(path=screenshot_path)
                logs.append(f"Screenshot: {screenshot_path}")

                # Step 3: Extract metrics from note manager DOM
                metrics = _extract_from_note_manager(page, platform_post_id, logs)

                context.close()

                if metrics is None:
                    logs.append("Note not found or data extraction failed")
                    return {
                        "success": False,
                        "errorCode": "metrics_fetch_note_not_found",
                        "errorMessage": f"笔记 {platform_post_id} 未在管理页找到或数据提取失败",
                        "executionLogs": logs,
                    }

                return {
                    "success": True,
                    "platformPostId": platform_post_id,
                    "views": metrics.get("views", 0),
                    "likes": metrics.get("likes", 0),
                    "favorites": metrics.get("favorites", 0),
                    "comments": metrics.get("comments", 0),
                    "followConversions": metrics.get("followConversions", 0),
                    "executionLogs": logs,
                }

            except Exception as e:
                logs.append(f"Page error: {e}")
                try:
                    page.screenshot(
                        path=os.path.join(SCREENSHOT_DIR, "metrics_error.png")
                    )
                except Exception:
                    pass
                context.close()
                return {
                    "success": False,
                    "errorCode": _classify_page_error(e),
                    "errorMessage": str(e),
                    "executionLogs": logs,
                }

    except Exception as e:
        logs.append(f"Browser error: {e}")
        return {
            "success": False,
            "errorCode": "metrics_fetch_browser_error",
            "errorMessage": str(e),
            "executionLogs": logs,
        }


def _extract_from_note_manager(page, platform_post_id: str, logs: list[str]) -> dict | None:
    """
    从笔记管理页 DOM 提取互动数据。
    页面结构：每条笔记一行，包含标题+日期+5个数字(views/likes/comments/favorites/shares)
    先通过标题匹配找到对应行，再提取数字。
    """
    try:
        # Strategy A: Use JS to find note card by data-id or data-note-id matching platformPostId
        found = page.evaluate(
            f"""
            () => {{
                // Look for any element with data-id matching the platformPostId
                const candidates = document.querySelectorAll('[data-id*="{platform_post_id}"]');
                if (candidates.length > 0) {{
                    const el = candidates[0];
                    const text = el.innerText || el.textContent || '';
                    return {{ found: 'by_data_id', text: text }};
                }}

                // Look for note rows with 5 consecutive numbers (the stats)
                const rows = document.querySelectorAll('[class*="note"], [class*="card"], [class*="item"], [class*="row"]');
                let bestMatch = null;
                for (const row of rows) {{
                    const text = row.innerText || row.textContent || '';
                    if (text.length > 30 && text.length < 500) {{
                        // Count numbers in the text
                        const nums = text.match(/\\d+/g);
                        if (nums && nums.length >= 5) {{
                            bestMatch = text;
                        }}
                    }}
                }}
                return bestMatch 
                    ? {{ found: 'by_numbers', text: bestMatch }} 
                    : {{ found: false, text: document.body.innerText.substring(0, 2000) }};
            }}
        """
        )

        logs.append(f"Page scan: {found.get('found', 'unknown')}")

        text = found.get("text", "")

        # If no match found, get raw body text
        if not text or found.get("found") == "by_data_id" and len(text) < 20:
            text = page.evaluate("() => document.body.innerText")
            logs.append("Using full body text")

        # Parse: find all number sequences in the body text
        # The note manager shows each note with: title, date, then 5 numbers (views likes comments favorites shares)
        lines = text.split("\n")

        # Find lines near the platformPostId or with number patterns
        # The stats appear as 5 consecutive numbers on one line or consecutive lines
        all_numbers = []
        for line in lines:
            stripped = line.strip()
            nums = [n.strip() for n in stripped.split() if n.strip().isdigit() or n.strip().endswith("万")]
            if len(nums) >= 5:
                all_numbers.append(nums)
            elif len(nums) >= 1 and len(stripped) < 50:
                all_numbers.append(nums)

        logs.append(f"Found {len(all_numbers)} lines with numbers")

        # The first line with 5+ numbers is usually the most recent note's stats
        for nums in all_numbers:
            if len(nums) >= 5:
                parsed = [parse_interaction_count(n) for n in nums[:5]]
                result = {
                    "views": parsed[0],
                    "likes": parsed[1],
                    "comments": parsed[2],
                    "favorites": parsed[3],
                    "followConversions": parsed[4],
                }
                logs.append(f"Metrics parsed: {result}")
                return result

        # Fallback: try to find any 5 numbers in the text
        import re
        all_ints = [parse_interaction_count(m) for m in re.findall(r'[\d.]+万?', text)]
        if len(all_ints) >= 5:
            result = {
                "views": all_ints[0],
                "likes": all_ints[1],
                "comments": all_ints[2],
                "favorites": all_ints[3],
                "followConversions": all_ints[4],
            }
            logs.append(f"Fallback parsed: {result}")
            return result

        logs.append("No valid number patterns found")
        return None

    except Exception as e:
        logs.append(f"DOM extraction error: {e}")
        return None


def _classify_page_error(exc: Exception) -> str:
    msg = str(exc).lower()
    if "timeout" in msg:
        return "metrics_fetch_timeout"
    if "net::" in msg:
        return "metrics_fetch_network_error"
    if "403" in msg or "404" in msg:
        return "metrics_fetch_post_not_found"
    return "metrics_fetch_page_error"


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(
            json.dumps(
                {
                    "success": False,
                    "errorCode": "missing_argument",
                    "errorMessage": "platformPostId required",
                }
            )
        )
        sys.exit(1)

    platform_post_id = sys.argv[1]
    headless = os.getenv("XHS_HEADLESS", "true").lower() != "false"
    result = fetch_metrics(platform_post_id, headless=headless)
    print(json.dumps(result, ensure_ascii=False))
