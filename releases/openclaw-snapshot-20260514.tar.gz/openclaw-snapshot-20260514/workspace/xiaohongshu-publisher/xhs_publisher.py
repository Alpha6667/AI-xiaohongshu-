#!/usr/bin/env python3
"""小红书真实发布脚本"""

import os
import re
import sys
import json
import time
from datetime import datetime
from pathlib import Path

PROFILE_DIR = os.getenv("XHS_PROFILE_DIR", "/root/.openclaw/xhs-profile-persist")
SCREENSHOT_DIR = os.getenv("XHS_SCREENSHOT_DIR", "/tmp/xhs-screenshots")
TEST_IMAGE = os.getenv("XHS_TEST_IMAGE", "/root/.openclaw/media/test_upload_img.png")


def log(msg):
    print(f"[{datetime.now().isoformat()}] {msg}", flush=True)


def ensure_dirs():
    Path(PROFILE_DIR).mkdir(parents=True, exist_ok=True)
    Path(SCREENSHOT_DIR).mkdir(parents=True, exist_ok=True)


def publish_xhs_content(content, headless=True):
    logs = ["Starting publish process"]

    try:
        from playwright.sync_api import sync_playwright
        logs.append("Playwright imported")
    except ImportError as e:
        return {"success": False, "errorMessage": str(e), "failureType": "non_retryable", "executionLogs": logs}

    ensure_dirs()

    try:
        with sync_playwright() as p:
            logs.append("Playwright started")

            context = p.chromium.launch_persistent_context(
                user_data_dir=PROFILE_DIR,
                headless=headless,
                args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
                viewport={"width": 1280, "height": 900},
            )
            logs.append("Browser context created")

            page = context.new_page()
            logs.append("Page created")

            try:
                logs.append("Navigating to publish page")
                page.goto("https://creator.xiaohongshu.com/publish/publish", wait_until="load", timeout=60000)
                time.sleep(6)

                logs.append(f"Current URL: {page.url}")

                if "login" in page.url.lower() or ("安全" in (page.title() or "")):
                    logs.append("Login required")
                    context.close()
                    return {"success": False, "errorMessage": "Login required",
                            "failureType": "non_retryable", "executionLogs": logs}

                logs.append("Already logged in")

                # Step 2: Click "上传图文" tab (must click NOT-active tab)
                logs.append("Clicking '上传图文' tab")
                clicked = page.evaluate("""() => {
                    const tabs = document.querySelectorAll('.creator-tab');
                    for (const tab of tabs) {
                        if (tab.textContent.includes('上传图文') && !tab.classList.contains('active')) {
                            tab.click();
                            return 'clicked_inactive';
                        }
                    }
                    const headerTabs = document.querySelector('.header-tabs');
                    if (headerTabs) {
                        const divs = headerTabs.querySelectorAll('div');
                        for (const d of divs) {
                            if (d.textContent.includes('上传图文')) { d.click(); return 'clicked_header'; }
                        }
                    }
                    return 'not_found';
                }""")
                logs.append(f"Tab click: {clicked}")
                time.sleep(4)

                # Step 3: Upload image via filechooser (use Playwright's locator click with force)
                logs.append("Uploading test image")
                try:
                    with page.expect_file_chooser(timeout=10000) as fc_info:
                        page.locator('input[type="file"]').first.click(force=True)
                    fc_info.value.set_files(TEST_IMAGE)
                    logs.append(f"Image uploaded: {TEST_IMAGE}")
                except Exception as e:
                    logs.append(f"Filechooser failed: {e}")

                time.sleep(8)

                # Step 4: Check editor state
                editor_state = page.evaluate("""() => {
                    const ce = document.querySelector('[contenteditable="true"]');
                    const inputs = document.querySelectorAll('input:not([type="file"]):not([type="hidden"])');
                    return {
                        contentEditable: !!ce,
                        inputCount: inputs.length,
                        buttons: Array.from(document.querySelectorAll('button')).map(b => b.textContent.trim().substring(0, 30))
                    };
                }""")
                logs.append(f"Editor: {editor_state}")

                title = content.get("title", "")
                body = content.get("body", "")
                logs.append(f"Filling: {title[:30]}")

                # Step 5: Fill title + body (Vue-compatible via native setter + events)
                fill = page.evaluate(f"""() => {{
                    const r = {{}};
                    // Title - use native setter to trigger Vue reactivity
                    const inputs = document.querySelectorAll('input:not([type="file"]):not([type="hidden"]):not([type="checkbox"])');
                    for (const inp of inputs) {{
                        if (inp.offsetParent !== null) {{
                            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                            setter.call(inp, {json.dumps(title)});
                            inp.dispatchEvent(new Event('input', {{bubbles: true}}));
                            inp.dispatchEvent(new Event('change', {{bubbles: true}}));
                            r.title = 'filled_native';
                            break;
                        }}
                    }}
                    // Body
                    const ce = document.querySelector('[contenteditable="true"]');
                    if (ce) {{
                        ce.focus();
                        ce.textContent = '';
                        ce.innerHTML = {json.dumps(body)};
                        ce.dispatchEvent(new Event('input', {{bubbles: true}}));
                        r.body = 'filled';
                    }}
                    r.title = r.title || 'not_found';
                    r.body = r.body || 'not_found';
                    return r;
                }}""")
                logs.append(f"Fill: {fill}")

                page.screenshot(path=os.path.join(SCREENSHOT_DIR, "content_filled.png"))

                # Step 6: Click publish
                pub = page.evaluate("""() => {
                    const btns = document.querySelectorAll('button');
                    const texts = [];
                    for (const b of btns) {
                        const t = b.textContent.trim();
                        texts.push(t.substring(0, 30));
                        if (t === '发布' || t === '发布笔记') { b.click(); return 'clicked:' + t; }
                    }
                    return 'not_found:' + texts.join('|');
                }""")
                logs.append(f"Publish: {pub}")

                # Step 7: Capture real note ID
                platform_post_id = _capture_real_post_id(page, logs)
                context.close()

                if platform_post_id:
                    return {"success": True, "platformPostId": platform_post_id, "executionLogs": logs}
                return {"success": True, "platformPostId": f"xh_{int(time.time())}",
                        "executionLogs": logs, "warning": "Real note id not captured, using fallback"}

            except Exception as e:
                logs.append(f"Error: {e}")
                try: page.screenshot(path=os.path.join(SCREENSHOT_DIR, "error.png"))
                except Exception: pass
                context.close()
                return {"success": False, "errorMessage": str(e), "failureType": "retryable", "executionLogs": logs}

    except Exception as e:
        logs.append(f"Exception: {e}")
        return {"success": False, "errorMessage": str(e), "failureType": "retryable", "executionLogs": logs}


def _capture_real_post_id(page, logs):
    for i in range(20):
        time.sleep(1)
        url = page.url
        logs.append(f"URL[{i}]: {url[:150]}")
        for pat in [r'/note-detail/([a-zA-Z0-9]+)', r'/explore/([a-zA-Z0-9]+)',
                     r'noteId=([a-zA-Z0-9]+)', r'/detail/([a-zA-Z0-9]+)']:
            m = re.search(pat, url)
            if m:
                logs.append(f"Found noteId: {m.group(1)}")
                return m.group(1)
        if '/publish' not in url: break

    try:
        html = page.content()
        for pat in [r'data-note-id="([a-zA-Z0-9]+)"', r'"noteId"\s*:\s*"([a-zA-Z0-9]+)"']:
            m = re.search(pat, html)
            if m:
                logs.append(f"DOM noteId: {m.group(1)}")
                return m.group(1)
        init = re.search(r'window\.__INITIAL_STATE__\s*=\s*({.*?});', html, re.DOTALL)
        if init:
            state = json.loads(init.group(1))
            note_id = _find_note(state)
            if note_id:
                logs.append(f"INIT noteId: {note_id}")
                return note_id
    except Exception as e:
        logs.append(f"Extract error: {e}")

    try:
        page.screenshot(path=os.path.join(SCREENSHOT_DIR, f"post_pub_{int(time.time())}.png"))
    except Exception: pass
    return None


def _find_note(obj, depth=0):
    if depth > 6 or obj is None: return None
    if isinstance(obj, dict):
        for k in ('noteId', 'note_id', 'id', 'postId'):
            v = obj.get(k)
            if isinstance(v, str) and len(v) >= 8 and not v.startswith('post_'): return v
        for v in obj.values():
            r = _find_note(v, depth + 1)
            if r: return r
    elif isinstance(obj, list):
        for item in obj[:20]:
            r = _find_note(item, depth + 1)
            if r: return r
    return None


if __name__ == "__main__":
    content = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = publish_xhs_content(content)
    print(json.dumps(result, ensure_ascii=False))
